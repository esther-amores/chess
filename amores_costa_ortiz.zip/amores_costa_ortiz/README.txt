Aquest fitxer .zip conté 4arxius: 
- chess.pdf -> Informe amb els resultats
- chess.R -> Script d'R
- kr-vs-kp.data -> Base de dades
- kr-vs-kp.names -> Descripció de la base de dades